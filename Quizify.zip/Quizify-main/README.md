# Quizify
The apk file of this app 
[app-debug.apk.zip](https://github.com/Smarshal21/Quizify/files/10287617/app-debug.apk.zip)
